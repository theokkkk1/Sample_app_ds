
abstract class DSTabBarDelegate {
  void onTabSelected(int index);
}