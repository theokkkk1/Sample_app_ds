package com.example.th_design_system_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
